<script lang="ts">
    import Room from '$lib/components/Room/Room.svelte';
</script>

<Room />
